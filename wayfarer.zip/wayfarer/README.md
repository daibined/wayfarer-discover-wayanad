# WAYFARER – Discover Wayanad
React + Vite + Tailwind CSS guide dedicated to Wayanad, Kerala.

## Setup
```
npm install
npm run dev      # http://localhost:5173
npm run build
```

## Photographs (important)
No photos are bundled; they must be authentic and licensed. For each destination put a real photo of that place at `public/images/<slug>.jpg` (slugs are in `src/data.js`, e.g. `edakkal-caves.jpg`). Until then a labelled placeholder is shown. Use your own photos or properly licensed ones (e.g. Wikimedia Commons with attribution).

## Accuracy policy
Entry fees, timings, permits and distances are deliberately **not included**. Verify with Kerala Forest Dept / DTPC Wayanad before adding. Every "best time" is marked as needing verification. Review all descriptions before launch.

## Structure
`src/data.js` content · `src/pages.jsx` pages · `src/components.jsx` reusable UI · `src/hooks.js` routing (hash), favourites (localStorage), reveal animation, titles.

Contact form validates but is a demo; connect a backend/service to deliver messages.
